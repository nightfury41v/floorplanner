import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.ArrayList;

public class FloorPlanner extends JFrame {
    private JPanel canvasPanel;
    private JPanel controlPanel;
    private ArrayList<Room> rooms;
    private Room selectedRoom;
    private Room draggedRoom;
    private Point dragStart;
    
    public FloorPlanner() {
        setTitle("2D Floor Planner");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 800);
        setLayout(new BorderLayout());
        
        rooms = new ArrayList<>();
        
        // Initialize canvas panel (3/4 width)
        canvasPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                drawRooms(g);
            }
        };
        canvasPanel.setBackground(Color.LIGHT_GRAY);
        canvasPanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                handleMousePressed(e);
            }
            
            @Override
            public void mouseReleased(MouseEvent e) {
                handleMouseReleased(e);
            }
        });
        canvasPanel.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                handleMouseDragged(e);
            }
        });
        
        // Initialize control panel (1/4 width)
        controlPanel = new JPanel();
        controlPanel.setPreferredSize(new Dimension(300, getHeight()));
        controlPanel.setBackground(Color.WHITE);
        controlPanel.setLayout(new BoxLayout(controlPanel, BoxLayout.Y_AXIS));
        
        // Add room creation buttons
        JButton addBedroomBtn = new JButton("Add Bedroom");
        JButton addBathroomBtn = new JButton("Add Bathroom");
        JButton addKitchenBtn = new JButton("Add Kitchen");
        JButton addLivingRoomBtn = new JButton("Add Living Room");
        
        addBedroomBtn.addActionListener(e -> addRoom("Bedroom", Color.GREEN));
        addBathroomBtn.addActionListener(e -> addRoom("Bathroom", Color.BLUE));
        addKitchenBtn.addActionListener(e -> addRoom("Kitchen", Color.RED));
        addLivingRoomBtn.addActionListener(e -> addRoom("Living Room", Color.ORANGE));
        
        controlPanel.add(addBedroomBtn);
        controlPanel.add(addBathroomBtn);
        controlPanel.add(addKitchenBtn);
        controlPanel.add(addLivingRoomBtn);
        
        add(canvasPanel, BorderLayout.CENTER);
        add(controlPanel, BorderLayout.EAST);
    }
    
    private void addRoom(String type, Color color) {
        Room room = new Room(type, color, 100, 100, 150, 150);
        if (!checkOverlap(room)) {
            rooms.add(room);
            canvasPanel.repaint();
        } else {
            JOptionPane.showMessageDialog(this, "Room overlaps with existing rooms!");
        }
    }
    
    private boolean checkOverlap(Room newRoom) {
        for (Room room : rooms) {
            if (room != newRoom && room.getBounds().intersects(newRoom.getBounds())) {
                return true;
            }
        }
        return false;
    }
    
    private void drawRooms(Graphics g) {
        for (Room room : rooms) {
            room.draw(g);
        }
    }
    
    private void handleMousePressed(MouseEvent e) {
        Point p = e.getPoint();
        for (Room room : rooms) {
            if (room.contains(p)) {
                selectedRoom = room;
                draggedRoom = room;
                dragStart = p;
                break;
            }
        }
    }
    
    private void handleMouseDragged(MouseEvent e) {
        if (draggedRoom != null) {
            Point p = e.getPoint();
            int dx = p.x - dragStart.x;
            int dy = p.y - dragStart.y;
            draggedRoom.setLocation(draggedRoom.x + dx, draggedRoom.y + dy);
            dragStart = p;
            canvasPanel.repaint();
        }
    }
    
    private void handleMouseReleased(MouseEvent e) {
        if (draggedRoom != null) {
            if (checkOverlap(draggedRoom)) {
                // Revert to original position
                draggedRoom.setLocation(dragStart.x, dragStart.y);
                JOptionPane.showMessageDialog(this, "Invalid position: Room overlaps!");
            }
            draggedRoom = null;
            dragStart = null;
            canvasPanel.repaint();
        }
    }
}

class Room extends Rectangle {
    private String type;
    private Color color;
    
    public Room(String type, Color color, int x, int y, int width, int height) {
        super(x, y, width, height);
        this.type = type;
        this.color = color;
    }
    
    public void draw(Graphics g) {
        g.setColor(color);
        g.fillRect(x, y, width, height);
        g.setColor(Color.BLACK);
        g.drawRect(x, y, width, height);
        g.drawString(type, x + 5, y + 20);
    }
}
