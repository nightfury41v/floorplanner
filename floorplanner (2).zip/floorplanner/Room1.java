import java.awt.*;

class Room1 extends Rectangle {
    private String type;
    private Color color;

    public Room1(String type, Color color, int x, int y, int width, int height) {
        super(x, y, width, height);
        this.type = type;
        this.color = color;
    }

    public void draw(Graphics g) {
        g.setColor(color);
        g.fillRect(x, y, width, height);
        g.setColor(Color.BLACK);
        g.drawRect(x, y, width, height);
        g.drawString(type, x + 5, y + 20);
    }
}