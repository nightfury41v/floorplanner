import javax.swing.*;
import java.awt.*;

public class CanvasPanel extends JPanel  {

    CanvasPanel(){
        this.setBackground(Color.PINK);
        this.setLayout(new FlowLayout());
        this.setPreferredSize(new Dimension(1500, 1920));
        this.setVisible(true);




    }



}
