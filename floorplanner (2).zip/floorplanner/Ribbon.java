import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ribbon extends JPanel  implements ActionListener {




    JButton saveButton = new JButton("save");
    JButton deleteButton = new JButton("delete room");

    Ribbon() {
        this.setBackground(Color.GRAY);
        this.setLayout(new FlowLayout());
        this.setPreferredSize(new Dimension(400, 1920));
        this.setVisible(true);

        this.add(saveButton);
        this.add(deleteButton);



    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==saveButton){
            ;
        }

    }
}
