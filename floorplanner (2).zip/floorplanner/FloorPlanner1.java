import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.ArrayList;

public class FloorPlanner1 extends JFrame  {

    ArrayList<Room1> rooms= new ArrayList<>();

    Ribbon ribbon= new Ribbon();
    public Room1 selectedRoom;
    public Room1 draggedRoom;
    public Point dragStart;
    CanvasPanel canvasPanel = new CanvasPanel();

    JButton addBedroomBtn = new JButton("Add Bedroom");
    JButton addBathroomBtn = new JButton("Add Bathroom");
    JButton addKitchenBtn = new JButton("Add Kitchen");
    JButton addLivingRoomBtn = new JButton("Add Living Room");

    public FloorPlanner1(){
        setLayout(new BorderLayout());
        setTitle("2D Floor Planner");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1920, 1080);
        ////////////////////////
        this.add(ribbon,BorderLayout.WEST);
        this.add(canvasPanel,BorderLayout.EAST);
        /////////////
        canvasPanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                handleMousePressed(e);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                handleMouseReleased(e);
            }
        });
        canvasPanel.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                handleMouseDragged(e);
            }
        });

        addBedroomBtn.addActionListener(e -> addRoom("Bedroom", Color.GREEN));
        addBathroomBtn.addActionListener(e -> addRoom("Bathroom", Color.BLUE));
        addKitchenBtn.addActionListener(e -> addRoom("Kitchen", Color.RED));
        addLivingRoomBtn.addActionListener(e -> addRoom("Living Room", Color.ORANGE));

        ribbon.add(addBedroomBtn);
        ribbon.add(addBathroomBtn);
        ribbon.add(addKitchenBtn);
        ribbon.add(addLivingRoomBtn);

    }

    public boolean checkOverlap(Room1 newRoom) {
        for (Room1 room : rooms) {
            if (room != newRoom && room.getBounds().intersects(newRoom.getBounds())) {
                return true;
            }
        }

        return false;
    }

    public void handleMousePressed(MouseEvent e) {
        Point p = e.getPoint();
        for (Room1 room : rooms) {
            if (room.contains(p)) {
                selectedRoom = room;
                draggedRoom = room;
                dragStart = p;
                break;
            }
        }
    }

    private void handleMouseDragged(MouseEvent e) {
        if (draggedRoom != null) {
            Point p = e.getPoint();
            int dx = p.x - dragStart.x;
            int dy = p.y - dragStart.y;
            draggedRoom.setLocation(draggedRoom.x + dx, draggedRoom.y + dy);
            dragStart = p;
            canvasPanel.repaint();
        }
    }

    private void handleMouseReleased(MouseEvent e) {
        if (draggedRoom != null) {
            if (checkOverlap(draggedRoom)) {
                // Revert to original position
                draggedRoom.setLocation(dragStart.x, dragStart.y);
                JOptionPane.showMessageDialog(this, "Invalid position: Room overlaps!");
            }
            draggedRoom = null;
            dragStart = null;
            canvasPanel.repaint();
        }
    }


    private void addRoom(String type, Color color) {
        Room1 room = new Room1(type, color, 100, 100, 150, 150);
        if (!checkOverlap(room)) {
            rooms.add(room);
            canvasPanel.repaint();
        } else {
            JOptionPane.showMessageDialog(this, "Room overlaps with existing rooms!");
        }
    }


}

