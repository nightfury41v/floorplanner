import javax.swing.*;
import java.awt.*;

public class RoomSelect extends JFrame{
    JFrame frame = new JFrame();
    JLabel label = new JLabel("hello");

    String[] TypesOfRooms={"Bedroom","Bathroom","Kitchen","Living Room"};

    JComboBox roomType;

    JTextField X = new JTextField("X");
    JTextField Y = new JTextField("Y");

    RoomSelect(){
        this.setSize(420,420);
        this.setLayout(new FlowLayout(FlowLayout.CENTER,50,20));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);



        label.setBounds(0,0,300,300);
        frame.add(label);
        setLayout(new BorderLayout());
        setTitle("Select Room");

        roomType=new JComboBox<>(TypesOfRooms);
        roomType.setPreferredSize(new Dimension(50,50));


        this.add(roomType);

        this.setVisible(true);

    }
}
